<?php return array (
  'disp' => 'FlightTracking',
  'icon' => '',
  'dash' => '',
  'hash' => 'FlightTracking__FlightTracking',
  'indexsidebar' => '',
  'user' => 'Auth',
  'gates' =>
  array (
  ),
  'submenu' =>
  array (
  ),
  'submodule' =>
  array (
  ),
  'models' =>
  array (
    'recent_search' =>
    array (
      0 => 'RecentSearch',
      1 => 'RecentSearch',
      2 => '',
    ),
  ),
);