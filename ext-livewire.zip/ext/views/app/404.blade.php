<?php
$path = explode('-',Request::path());

// // return address suggestions
// if($path[0]=="flighttracking/flight/autocomplete"){

// }