<?php 
namespace App\Custom\FlightTracking\Livewire\FlightComponent;
use Livewire\Component;

class FlightSearchForm extends Component
{
  public function render()
  {
    return view('custom.FlightTracking.component.flightsearchform');
  }
}