<div class="bg-red">
  hello this is a component
</div>