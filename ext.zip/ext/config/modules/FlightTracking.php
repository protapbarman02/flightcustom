<?php return array (
  'disp' => 'FlightTracking',
  'icon' => '',
  'dash' => '',
  'hash' => 'FlightTracking__FlightTracking',
  'indexsidebar' => '',
  'user' => 'Auth',
  'gates' =>
  array (
  ),
  'submenu' =>
  array (
  ),
  'submodule' =>
  array (
    'Flight' =>
    array (
      0 => 'Flight',
      1 => '',
      2 => 'Auth',
    ),
    'RecentSearch' =>
    array (
      0 => 'RecentSearch',
      1 => '',
      2 => 'Auth',
    ),
    'Home' =>
    array (
      0 => 'Home',
      1 => '',
      2 => 'Auth',
    ),
    'Distance' =>
    array (
      0 => 'Distance',
      1 => '',
      2 => 'Auth',
    ),
  ),
  'models' =>
  array (
    'recent_search' =>
    array (
      0 => 'RecentSearch',
      1 => 'RecentSearch',
      2 => '',
    ),
  ),
);